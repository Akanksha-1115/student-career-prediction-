# Student Career Prediction — Professional Streamlit UI

This project is based on the supplied `student-career-prediction.ipynb`.

## Run locally

1. Put `student_career_success_dataset.csv` beside `app.py` (or upload it in the sidebar).
2. Install packages:

```bash
pip install -r requirements.txt
```

3. Start Streamlit:

```bash
streamlit run app.py
```

## Pages

- Dashboard
- Predict
- Analytics
- Model

The app uses the Random Forest configuration from the notebook:
- 200 estimators
- max_depth=12
- min_samples_split=5
- min_samples_leaf=2
- random_state=42
- class_weight="balanced"

The notebook's reported test accuracy is 1.0. The UI includes a deployment warning because some supplied features look like post-placement information and may cause target leakage.
